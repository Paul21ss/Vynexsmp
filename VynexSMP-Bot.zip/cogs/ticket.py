
import discord
from discord.ext import commands

class Ticket(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def ticket(self, ctx, *, reason=None):
        guild = ctx.guild
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            ctx.author: discord.PermissionOverwrite(read_messages=True),
            guild.get_role(int(self.bot.config["staff_role_id"])): discord.PermissionOverwrite(read_messages=True)
        }
        channel = await guild.create_text_channel(
            name=f"ticket-{ctx.author.name}", overwrites=overwrites
        )
        await channel.send(f"{ctx.author.mention} Ticket erstellt! Grund: {reason}")

    @commands.command()
    async def close(self, ctx):
        if "ticket-" in ctx.channel.name:
            await ctx.channel.delete()
        else:
            await ctx.send("Dies ist kein Ticket-Kanal.")

async def setup(bot):
    bot.config = bot.config if hasattr(bot, 'config') else {}
    await bot.add_cog(Ticket(bot))
